/**
 * Created with IntelliJ IDEA.
 * User: eric
 * Date: 07/10/13
 * Time: 7:11 PM
 * To change this template use File | Settings | File Templates.
 */
import java.util.Scanner; //needed for scanner

public class ClassWork
{
    private int id;
    private String names;
    private char eType;
    private double totalPay;
    private double payRate;
    private double hours;

    /**modifiers**/
    public void setID(int pID)
    {
        id = pID;
    }
    public void setNames(String pNames)
    {
        names = pNames;
    }
    public void seteType(char pEType)
    {
        eType = pEType;
    }
    public void setPay(double pPayRate)
    {
        payRate = pPayRate;
    }
    public void setHours(double pHours)
    {
        hours = pHours;
    }

    /**Accessors**/
    public int getId()
    {
        return id;
    }
    public String getNames()
    {
        return names;
    }
    public char geteType()
    {
        return eType;
    }
    public double getPay()
    {
        return payRate;
    }
    public double getHours()
    {
        return hours;
    }

    //double pHours, char pEtype, String pName

    public void calcPay()
    {

        totalPay = payRate * hours;

        if(eType == 'H' || eType == 'h')
        {
            System.out.println("You are hourly");
            totalPay = payRate * hours;
            totalPay = totalPay - 15.00;
        }
        else if (eType == 'S' || eType == 's')
        {
            System.out.println("You are salary");
            totalPay = payRate * 40;
            totalPay = totalPay - 45.00;
        }
        else
        {
            System.out.println("Do you even work here?");
            System.exit(0);
        }
        System.out.println("Your salary is $"+totalPay);


        //boolean luckyDay = true;
        /*
        if (luckyDay)
            System.out.println("it is your lucky day.");


        if (pEtype == 'H' || pEtype == 'h')
            System.out.println("You are hourly.");
        else
            System.out.println("You are salary");

        if (pName.equals("Murray") && !luckyDay)
            System.out.println("You're Fired, go home.");
        if (pName.compareTo("Nizyborski") == 0)
            System.out.println("You are promoted.");


        if (payRate * pHours >= 50.0)
            System.out.println("You are overpaid.");
        else
            System.out.println("You are underpaid.");
        */



    }


}
